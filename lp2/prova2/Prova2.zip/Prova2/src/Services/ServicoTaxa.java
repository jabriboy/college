package Services;

public interface ServicoTaxa {
    public Double calculaTaxa(Double valorDiaria);
}
